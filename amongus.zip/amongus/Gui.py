from tkinter import *
from client import Client
##########################################################################################

class Player():
    def __init__(self, startx, starty, color):
        self.x = startx
        self.y = starty
        self.color = color
        self.rate = 10

    def draw (self):
        PlayerIMG = PhotoImage(file= self.color)
        my_canvas.create_image(self.x, self.y, anchor=NW, image=PlayerIMG)

    def move(self, directKey):
        if directKey == 0:#right
            self.x = self.x + self.rate
            my_canvas.move(self, self.x, self.y)
        elif directKey == 1:#left
            self.x = self.x - self.rate
            my_canvas.move(self, self.x, self.y)
        elif directKey == 2:#up
            self.y = self.y - self.rate
            my_canvas.move(self, self.x, self.y)
        else:#down
            self.y = self.y + self.rate
            my_canvas.move(self, self.x, self.y)



#############################################################################################
#Creating GUI
root = Tk()
root.title('Version 1.0')
root.geometry("695x530")
#network = Client()


w = 695
h = 530
x = w/2
y = h/2

global my_canvas
my_canvas = Canvas(root, width = w, height = h, bg="black")
my_canvas.pack()

backgroundIMG = PhotoImage(file = "Images/starz.png")
my_canvas.create_image(0, 0, anchor= NW, image = backgroundIMG)
my_canvas.create_image(0, 0, anchor= NE, image = backgroundIMG)
my_canvas.create_image(0, 0, anchor= SW, image = backgroundIMG)
my_canvas.create_image(0, 0, anchor= SE, image = backgroundIMG)


PlayerIMG = PhotoImage(file= "Images/cyan.png")
Player1 = my_canvas.create_image(0, 0, anchor=NW, image=PlayerIMG)

############################################################################################
def left(event):
    x = -10
    y = 0
    my_canvas.move(Player1, x, y)

def right(event):
    x = 10
    y = 0
    my_canvas.move(Player1, x, y)

def up(event):
    x = 0
    y = -10
    my_canvas.move(Player1, x, y)

def down(event):
    x = 0
    y = 10
    my_canvas.move(Player1, x, y)

#Binding keys pressed
root.bind("<Left>", left)
root.bind("<Right>", right)
root.bind("<Up>", up)
root.bind("<Down>", down)

root.mainloop()


