import amongUs

#just runs the game
if __name__ == "__main__":
    code = amongUs.Game(850, 638)
    code.run()
